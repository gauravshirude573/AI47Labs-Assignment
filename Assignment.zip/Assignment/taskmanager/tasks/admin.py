from django.contrib import admin
from .models import GoogleOAuthKey, Task
from django.utils.crypto import get_random_string
from django.core.mail import send_mail
from .models import Invitation

admin.site.register(GoogleOAuthKey)
admin.site.register(Task)


@admin.action(description="Send Invitations")
def send_invitations(modeladmin, request, queryset):
    for invitation in queryset:
        if not invitation.is_accepted:
            token = invitation.token or get_random_string(64)
            invitation.token = token
            invitation.save()
            link = f"http://127.0.0.1:8000/register/{token}/"
            
            # Send the email (output will go to the console)
            send_mail(
                subject="You're Invited to Task Manager",
                message=f"Please register using the following link: {link}",
                from_email="no-reply@taskmanager.com",
                recipient_list=[invitation.email],
            )

@admin.register(Invitation)
class InvitationAdmin(admin.ModelAdmin):
    list_display = ('email', 'is_accepted')
    actions = [send_invitations]
