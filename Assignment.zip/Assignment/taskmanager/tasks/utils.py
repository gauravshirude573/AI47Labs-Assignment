from django.core.mail import send_mail

def send_invite(email, link):
    send_mail(
        'Invitation to Task Manager',
        f'You are invited to join Task Manager. Use this link to register: {link}',
        'admin@taskmanager.com',
        [email],
    )

