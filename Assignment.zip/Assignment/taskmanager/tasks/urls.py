from django.urls import path
from . import views
from tasks.views import custom_login, register

urlpatterns = [
    path('', views.task_list, name='task_list'),
    path('create/', views.task_create, name='task_create'),
    path('edit/<int:task_id>/', views.task_edit, name='task_edit'),
    path('delete/<int:task_id>/', views.task_delete, name='task_delete'),
    path('accounts/login/', custom_login, name='account_login'),
    path('register/<str:token>/', register, name='register'),
]
