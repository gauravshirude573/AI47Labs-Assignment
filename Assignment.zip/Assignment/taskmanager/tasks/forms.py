from django import forms

class InvitationForm(forms.Form):
    email = forms.EmailField(label='Invite user by email', max_length=100)