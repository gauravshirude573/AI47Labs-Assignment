from django.shortcuts import render, redirect, get_object_or_404
from django.contrib.auth.decorators import login_required
from .models import Task
from .models import Invitation
from django.contrib.auth.models import User

@login_required
def task_list(request):
    tasks = Task.objects.filter(user=request.user)
    return render(request, 'tasks/task_list.html', {'tasks': tasks})

@login_required
def task_create(request):
    if request.method == "POST":
        title = request.POST.get('title')
        description = request.POST.get('description')
        Task.objects.create(user=request.user, title=title, description=description)
        return redirect('task_list')
    return render(request, 'tasks/task_form.html')

@login_required
def task_edit(request, task_id):
    task = get_object_or_404(Task, id=task_id, user=request.user)
    if request.method == "POST":
        task.title = request.POST.get('title')
        task.description = request.POST.get('description')
        task.save()
        return redirect('task_list')
    return render(request, 'tasks/task_form.html', {'task': task})

@login_required
def task_delete(request, task_id):
    task = get_object_or_404(Task, id=task_id, user=request.user)
    task.delete()
    return redirect('task_list')

def homepage(request):
    return render(request, 'homepage.html')

def custom_login(request):
    if request.user.is_authenticated:
        return redirect('/tasks/')
    return render(request, 'account/login.html')

def register(request, token):
    invitation = Invitation.objects.filter(token=token, is_accepted=False).first()
    if not invitation:
        return render(request, 'invalid_token.html')

    if request.method == "POST":
        username = request.POST['username']
        password = request.POST['password']
        user = User.objects.create_user(username=username, email=invitation.email, password=password)
        invitation.is_accepted = True
        invitation.save()
        return redirect('login')  # Redirect to login after successful registration

    return render(request, 'register.html', {'email': invitation.email})
